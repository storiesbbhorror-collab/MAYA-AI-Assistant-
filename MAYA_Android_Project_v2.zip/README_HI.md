# MAYA AI — Android प्रोजेक्ट (v1.0)

यह एक शुरुआती native Android project है, जिसे GitHub Actions से मुफ्त में debug APK बनाया जा सकता है। यह पहले से signed/Play Store-ready APK नहीं है।

## इसमें क्या है
- हिंदी Text-to-Speech और फोन के Speech Recognizer से बोलकर कमांड देना
- वैकल्पिक Gemini 2.5 Flash chat (API key स्क्रीन पर डालें; इस session में memory में रहती है)
- स्थानीय Notes, Tasks, command history
- स्थानीय reminders और notification
- बैटरी स्तर, कैमरा फ्लैशलाइट टॉगल
- दूसरे ऐप खोलने की कोशिश (नाम के आधार पर)
- Phone dial screen और SMS draft खोलना
- डिफ़ॉल्ट Phone/Dialer role के लिए अनुरोध तथा incoming call accept/reject UI का आधार
- Android Notification Access सक्षम करने पर notification title/text की स्थानीय आवाज़ में घोषणा
- स्थानीय notes/tasks/history का text backup share
- dark/light theme toggle
- Google Search में मौसम/वेब खोज और गेमिंग सहायता

## स्पष्ट सीमाएँ
- “Hey MAYA” हमेशा सुनने वाला wake word शामिल नहीं है; Android में लगातार background microphone के लिए अतिरिक्त foreground service, notification, battery/privacy handling और परीक्षण चाहिए।
- AI और web search के लिए इंटरनेट चाहिए। Notes/tasks/reminders जैसी स्थानीय सुविधाएँ offline काम करती हैं।
- Gemini API key APK में रखने से उसे reverse-engineering से पूरी तरह सुरक्षित नहीं रखा जा सकता। इस demo में key स्थायी रूप से save नहीं होती; उत्पादन ऐप के लिए server proxy बेहतर है।
- कॉल accept/reject तभी काम कर सकता है जब डिवाइस MAYA को default Phone/Dialer role दे और Android/OEM इसे अनुमति दे। यह पूर्ण replacement dialer का प्रमाणित उत्पाद नहीं है; अलग-अलग फोन पर परीक्षण ज़रूरी है।
- Notification announcement केवल तब चलेगी जब user Android Settings में Notification Access खुद enable करे। इससे notifications का निजी text पढ़ा जा सकता है; इसे केवल अपने फोन पर सक्षम करें। SMS पढ़ने/भेजने की direct permission शामिल नहीं है।
- SMS भेजने के बजाय SMS app में draft खुलता है; user को खुद जाँचकर भेजना होगा।
- Android 13+ में notifications की अनुमति आवश्यक हो सकती है।
- यह ऐप किसी भी सुरक्षा lock, permission prompt या Android restrictions को bypass नहीं करता।

## Android फोन से APK बनाने के मुफ्त चरण
1. इस ZIP को डाउनलोड करके extract करें।
2. GitHub पर नया repository बनाएँ और सभी project files upload करें (root में `settings.gradle.kts`, `build.gradle.kts`, `app/` और `.github/` हों)।
3. `Actions` tab खोलें और `Build MAYA APK` workflow चलाएँ या push होने दें।
4. Workflow के सफल होने पर run के नीचे `maya-debug-apk` artifact डाउनलोड करें।
5. ZIP extract करके `app-debug.apk` अपने Android फोन में खोलें। Android पूछे तो केवल अपने बनाए APK के लिए install permission दें।
6. पहली बार app खोलकर Android prompts को ध्यान से पढ़ें। Phone role और Notification Access वैकल्पिक हैं।

## API key
Gemini API key Google AI Studio से अपने खाते में बनानी होगी। Free quota/उपलब्धता Google की वर्तमान शर्तों पर निर्भर है। API key किसी सार्वजनिक GitHub file में न डालें।

## तकनीकी विवरण
- Package: `com.maya.assistant`
- Minimum Android: 8.0 (API 26)
- Target/Compile SDK: 35
- APK type: debug APK, test build; production signing नहीं।
