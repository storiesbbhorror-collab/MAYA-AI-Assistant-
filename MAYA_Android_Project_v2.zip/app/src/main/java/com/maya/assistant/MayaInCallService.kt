package com.maya.assistant

import android.telecom.Call
import android.telecom.InCallService

object MayaCallHolder {
    @Volatile var currentCall: Call? = null
}

class MayaInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        MayaCallHolder.currentCall = call
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                if (state == Call.STATE_DISCONNECTED) {
                    if (MayaCallHolder.currentCall === call) MayaCallHolder.currentCall = null
                }
            }
        })
        try {
            startActivity(android.content.Intent(this, IncomingCallActivity::class.java)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (_: Exception) { }
    }
    override fun onCallRemoved(call: Call) {
        if (MayaCallHolder.currentCall === call) MayaCallHolder.currentCall = null
        super.onCallRemoved(call)
    }
}
