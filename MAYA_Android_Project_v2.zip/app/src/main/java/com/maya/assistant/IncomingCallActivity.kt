package com.maya.assistant

import android.app.Activity
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class IncomingCallActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val call = MayaCallHolder.currentCall
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF07111E.toInt())
        }
        val details = TextView(this).apply {
            textSize = 22f; setTextColor(0xFFE5F4FF.toInt()); gravity = Gravity.CENTER
            text = when (call?.state) {
                Call.STATE_RINGING -> "📞 इनकमिंग कॉल\n${call.details?.handle ?: "अज्ञात नंबर"}"
                Call.STATE_ACTIVE -> "कॉल चालू है\n${call.details?.handle ?: ""}"
                else -> "MAYA कॉल कंट्रोल"
            }
        }
        box.addView(details)
        val answer = Button(this).apply {
            text = "कॉल स्वीकार करें"; isAllCaps = false
            setOnClickListener {
                MayaCallHolder.currentCall?.let { c -> if (c.state == Call.STATE_RINGING) c.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY) }
                finish()
            }
        }
        val reject = Button(this).apply {
            text = "कॉल अस्वीकार / समाप्त करें"; isAllCaps = false
            setOnClickListener { MayaCallHolder.currentCall?.disconnect(); finish() }
        }
        box.addView(answer); box.addView(reject); setContentView(box)
    }
    override fun onResume() {
        super.onResume()
        if (MayaCallHolder.currentCall == null) finish()
    }
}
