package com.maya.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class MayaNotificationListener : NotificationListenerService() {
    private var speaker: TextToSpeech? = null
    override fun onCreate() {
        super.onCreate()
        speaker = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) speaker?.setLanguage(Locale("hi", "IN"))
        }
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val combined = listOf(title, text).filter { it.isNotBlank() }.joinToString(". ")
        // User explicitly enables Notification Access in Android Settings; announcement remains on-device.
        speaker?.speak("सूचना। $combined", TextToSpeech.QUEUE_ADD, null, "maya_notification_${sbn.id}")
    }
    override fun onDestroy() {
        speaker?.stop(); speaker?.shutdown(); speaker = null
        super.onDestroy()
    }
}
