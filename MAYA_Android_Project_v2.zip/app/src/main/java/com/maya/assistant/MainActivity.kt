package com.maya.assistant

import android.Manifest
import android.app.*
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.*
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var apiKeyBox: EditText
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("maya_local", MODE_PRIVATE) }
    private var torchOn = false
    private var dark = true
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        createChannels()
        buildUi()
        show("MAYA ऑनलाइन है। नीचे बोलें या कमांड लिखें।\nस्थानीय नोट्स और टास्क इंटरनेट के बिना भी काम करते हैं।")
        requestNotificationPermission()
        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent) {
        if (intent.getBooleanExtra("maya_wake_triggered", false)) {
            show("हाँ, मैं सुन रही हूँ। अब अपना सवाल बोलने के लिए 🎙 बोलें।")
            speak("हाँ, मैं सुन रही हूँ।")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
        }
        setContentView(root)
        applyTheme()
        val title = TextView(this).apply {
            text = "◈ MAYA AI"
            textSize = 28f; gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "HINDI VOICE ASSISTANT • LOCAL-FIRST"
            textSize = 11f; gravity = Gravity.CENTER
        }
        root.addView(subtitle)

        val avatar = MayaAvatarView(this)
        root.addView(avatar, LinearLayout.LayoutParams(-1, dp(180)))

        output = TextView(this).apply {
            textSize = 15f; setPadding(12, 14, 12, 14)
            minHeight = 100
        }
        val scroll = ScrollView(this)
        scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply { hint = "कमांड लिखें… जैसे टॉर्च चालू करो"; setSingleLine(false) }
        root.addView(input)
        apiKeyBox = EditText(this).apply {
            hint = "Gemini API key (वैकल्पिक, केवल इस session में)"
            inputType = 129
        }
        root.addView(apiKeyBox)

        val row1 = LinearLayout(this)
        row1.addView(btn("▶ चलाएँ") { runCommand(input.text.toString()) }, weightParams())
        row1.addView(btn("🎙 बोलें") { startVoice() }, weightParams())
        root.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(btn("📝 नोट") { promptFor("नोट लिखें") { addItem("notes", it); show("नोट सेव हो गया।") } }, weightParams())
        row2.addView(btn("☑ टास्क") { promptFor("टास्क लिखें") { addItem("tasks", it); show("टास्क सेव हो गया।") } }, weightParams())
        root.addView(row2)
        val row3 = LinearLayout(this)
        row3.addView(btn("⏰ रिमाइंडर") { createReminderDialog() }, weightParams())
        row3.addView(btn("📚 नोट्स/टास्क") { showLocalItems() }, weightParams())
        root.addView(row3)
        val row4 = LinearLayout(this)
        row4.addView(btn("📞 कॉल सेटअप") { requestDialerRole() }, weightParams())
        row4.addView(btn("🔔 घोषणा सेटअप") { openNotificationAccess() }, weightParams())
        root.addView(row4)
        val row5 = LinearLayout(this)
        row5.addView(btn("💾 बैकअप") { shareBackup() }, weightParams())
        row5.addView(btn("◐ थीम") { dark = !dark; applyTheme() }, weightParams())
        root.addView(row5)
        val row6 = LinearLayout(this)
        row6.addView(btn("🎧 Hey MAYA चालू") { startWakeWord() }, weightParams())
        row6.addView(btn("⏹ Wake word बंद") { stopWakeWord() }, weightParams())
        root.addView(row6)
        root.addView(btn("🌐 मौसम / वेब सर्च") {
            val q = input.text.toString().ifBlank { "मौसम आज" }
            openWeb(q)
        })
        root.addView(btn("🎮 गेमिंग असिस्टेंट") {
            val q = input.text.toString().ifBlank { "मुझे गेमिंग टिप्स दो" }
            askAi("गेमिंग सहायक के रूप में हिंदी में मदद करो: $q")
        })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun startWakeWord() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 45)
            show("Hey MAYA शुरू करने के लिए माइक्रोफ़ोन अनुमति दें, फिर बटन दोबारा दबाएँ।")
            return
        }
        try {
            val intent = Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            show("Hey MAYA सुनना शुरू कर रहा है। बोलें: “Hey MAYA” या “हे माया”।")
            speak("मैं सुन रही हूँ। कहिए, हे माया।")
        } catch (e: Exception) {
            show("Wake word शुरू नहीं हो सका: ${e.message}")
        }
    }

    private fun stopWakeWord() {
        stopService(Intent(this, WakeWordService::class.java))
        show("Hey MAYA listening बंद कर दिया।")
        speak("Wake word बंद कर दिया।")
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3, 3, 3, 3) }
    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
    }
    private fun applyTheme() {
        val bg = if (dark) 0xFF07111E.toInt() else 0xFFF2F6FA.toInt()
        val fg = if (dark) 0xFFE5F4FF.toInt() else 0xFF102033.toInt()
        root.setBackgroundColor(bg)
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            if (v is TextView) v.setTextColor(fg)
            if (v is EditText) { v.setTextColor(fg); v.setHintTextColor(if (dark) 0xFF8DA4B8.toInt() else 0xFF657786.toInt()) }
        }
    }
    private fun show(text: String) {
        runOnUiThread {
            output.text = text
            prefs.edit().putString("last_status", text).apply()
        }
    }
    private fun speak(text: String) {
        if (ttsReady) tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "maya_speech")
    }
    private fun startVoice() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "MAYA को कमांड दें")
            }
            startActivityForResult(i, 110)
        } catch (_: Exception) {
            show("इस फोन पर speech recognition उपलब्ध नहीं है।")
        }
    }

    private fun runCommand(raw: String) {
        val q = raw.trim()
        if (q.isBlank()) { show("पहले कमांड लिखें या बोलें।"); return }
        val low = q.lowercase(Locale.ROOT)
        saveHistory(q)
        when {
            low.contains("टॉर्च") || low.contains("torch") || low.contains("flashlight") -> toggleTorch()
            low.contains("बैटरी") || low.contains("battery") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                show("बैटरी स्तर: $level%"); speak("आपके फोन की बैटरी $level प्रतिशत है।")
            }
            low.startsWith("नोट ") || low.startsWith("note ") -> {
                addItem("notes", q.substringAfter(' ')); show("नोट सेव हो गया।"); speak("नोट सेव हो गया।")
            }
            low.startsWith("टास्क ") || low.startsWith("task ") || low.startsWith("todo ") -> {
                addItem("tasks", q.substringAfter(' ')); show("टास्क सेव हो गया।"); speak("टास्क सेव हो गया।")
            }
            low.contains("रिमाइंडर") || low.contains("reminder") -> createReminderDialog()
            low.contains("कॉल") || low.contains("call") -> {
                val number = q.filter { it.isDigit() || it == '+' }
                val uri = if (number.isNotBlank()) Uri.parse("tel:$number") else Uri.parse("tel:")
                startActivity(Intent(Intent.ACTION_DIAL, uri))
                show("फोन ऐप खुल गया। कॉल करने के लिए पुष्टि फोन ऐप में करें।")
            }
            low.contains("मैसेज") || low.contains("message") || low.contains("sms") -> {
                val number = q.filter { it.isDigit() || it == '+' }
                val uri = Uri.parse("smsto:${number}")
                val i = Intent(Intent.ACTION_SENDTO, uri).apply {
                    putExtra("sms_body", q.substringAfter(" ", "नमस्ते"))
                }
                try { startActivity(i); show("मैसेज ड्राफ्ट खुल गया। भेजने से पहले जाँचें।") }
                catch (_: Exception) { show("इस फोन में SMS ऐप उपलब्ध नहीं है।") }
            }
            low.contains("मौसम") || low.contains("weather") || low.contains("सर्च") || low.contains("search") ||
                low.startsWith("खोजो") -> openWeb(q)
            low.startsWith("खोलो ") || low.startsWith("open ") -> launchApp(q.substringAfter(' ').trim())
            low.contains("कौन") && low.contains("हो") -> { show("मैं MAYA हूँ, आपका हिंदी AI सहायक।"); speak("मैं माया हूँ, आपका हिंदी एआई सहायक।") }
            else -> askAi(q)
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { show("इस फोन में फ्लैशलाइट उपलब्ध नहीं है।"); return }
            torchOn = !torchOn; cm.setTorchMode(id, torchOn)
            val s = if (torchOn) "टॉर्च चालू है।" else "टॉर्च बंद है।"
            show(s); speak(s)
        } catch (e: Exception) { show("टॉर्च चालू नहीं हो सकी: ${e.message}") }
    }

    private fun launchApp(name: String) {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString()
            label.contains(name, ignoreCase = true)
        }
        if (match != null) {
            val intent = pm.getLaunchIntentForPackage(match.packageName)
            if (intent != null) { startActivity(intent); show("${pm.getApplicationLabel(match)} खोल रहा हूँ।"); return }
        }
        show("ऐप नहीं मिला: $name. नाम अंग्रेज़ी में भी आज़माएँ।")
    }

    private fun openWeb(query: String) {
        val q = if (query.contains("मौसम") || query.contains("weather")) "मौसम आज" else query
        val url = "https://www.google.com/search?q=" + Uri.encode(q)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        show("वेब सर्च खोला: $q")
    }

    private fun askAi(prompt: String) {
        val key = apiKeyBox.text.toString().trim()
        if (key.isBlank()) {
            show("AI चैट के लिए Gemini API key डालें। बिना API key के स्थानीय कमांड, नोट्स, टास्क, बैटरी और टॉर्च काम करते हैं।")
            return
        }
        show("MAYA सोच रही है…")
        thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${Uri.encode(key)}")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                    setRequestProperty("Content-Type", "application/json"); doOutput = true
                }
                val body = JSONObject().put("contents", JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "तुम MAYA हो, एक उपयोगी हिंदी वॉइस असिस्टेंट। सरल हिंदी में जवाब दो। यूज़र का संदेश: $prompt")))
                )).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val answer = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text") ?: "जवाब नहीं मिला। API key और इंटरनेट जाँचें।"
                runOnUiThread { show("आप: $prompt\n\nMAYA: $answer"); speak(answer); saveHistory("आप: $prompt\nMAYA: $answer") }
            } catch (e: Exception) {
                show("AI कनेक्शन नहीं हुआ: ${e.message}\nAPI key और इंटरनेट कनेक्शन जाँचें।")
            } finally { conn?.disconnect() }
        }
    }

    private fun addItem(kind: String, value: String) {
        val arr = JSONArray(prefs.getString(kind, "[]"))
        arr.put(JSONObject().put("text", value).put("time", System.currentTimeMillis()).put("done", false))
        prefs.edit().putString(kind, arr.toString()).apply()
    }
    private fun saveHistory(value: String) {
        val arr = JSONArray(prefs.getString("history", "[]"))
        arr.put(JSONObject().put("text", value).put("time", System.currentTimeMillis()))
        while (arr.length() > 150) arr.remove(0)
        prefs.edit().putString("history", arr.toString()).apply()
    }
    private fun showLocalItems() {
        val b = StringBuilder("आपके स्थानीय डेटा\n\nनोट्स:\n")
        appendItems(b, "notes")
        b.append("\nटास्क:\n"); appendItems(b, "tasks")
        b.append("\n\nहाल की कमांड:\n")
        val h = JSONArray(prefs.getString("history", "[]"))
        for (i in maxOf(0, h.length() - 10) until h.length()) b.append("• ").append(h.optJSONObject(i)?.optString("text")).append('\n')
        show(b.toString())
    }
    private fun appendItems(b: StringBuilder, key: String) {
        val arr = JSONArray(prefs.getString(key, "[]"))
        if (arr.length() == 0) b.append("• अभी खाली\n")
        for (i in 0 until arr.length()) b.append("• ").append(arr.optJSONObject(i)?.optString("text")).append('\n')
    }
    private fun promptFor(title: String, save: (String) -> Unit) {
        val edit = EditText(this); edit.hint = title
        AlertDialog.Builder(this).setTitle(title).setView(edit)
            .setPositiveButton("सेव करें") { _, _ -> val s = edit.text.toString().trim(); if (s.isNotEmpty()) save(s) }
            .setNegativeButton("रद्द", null).show()
    }
    private fun createReminderDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 4, 18, 4) }
        val what = EditText(this).apply { hint = "किस बात की याद दिलानी है?" }
        val mins = EditText(this).apply { hint = "कितने मिनट बाद? (जैसे 10)"; inputType = 2 }
        box.addView(what); box.addView(mins)
        AlertDialog.Builder(this).setTitle("MAYA रिमाइंडर").setView(box)
            .setPositiveButton("सेट करें") { _, _ ->
                val message = what.text.toString().ifBlank { "आपका रिमाइंडर" }
                val minutes = mins.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 10L
                val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
                val pi = PendingIntent.getBroadcast(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60000, pi)
                addItem("tasks", "रिमाइंडर: $message ($minutes मिनट)")
                show("$minutes मिनट बाद रिमाइंडर सेट किया।"); speak("रिमाइंडर सेट कर दिया।")
            }.setNegativeButton("रद्द", null).show()
    }
    private fun shareBackup() {
        val json = JSONObject()
            .put("notes", JSONArray(prefs.getString("notes", "[]")))
            .put("tasks", JSONArray(prefs.getString("tasks", "[]")))
            .put("history", JSONArray(prefs.getString("history", "[]")))
            .toString(2)
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "MAYA Backup")
            .putExtra(Intent.EXTRA_TEXT, json)
        startActivity(Intent.createChooser(i, "MAYA backup share/save"))
    }
    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 120)
            } else if (rm.isRoleHeld(RoleManager.ROLE_DIALER)) show("MAYA डिफ़ॉल्ट Phone ऐप है। कॉल स्क्रीन/डिवाइस compatibility जाँचें।")
            else show("इस डिवाइस पर Dialer role उपलब्ध नहीं है।")
        } else show("इस Android संस्करण पर डिफ़ॉल्ट Phone ऐप सेटिंग से चुनें।")
    }
    private fun openNotificationAccess() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        show("Notification access में MAYA को अनुमति दें। घोषणा बंद करने के लिए वही अनुमति हटाएँ।")
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA), 44)
    }
    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("maya_reminders", "MAYA Reminders", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel("maya_calls", "MAYA Call controls", NotificationManager.IMPORTANCE_HIGH))
        }
    }
    @Deprecated("Legacy callback used to avoid adding AndroidX Activity dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 110 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!words.isNullOrEmpty()) {
                input.setText(words[0])
                runCommand(words[0])
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
