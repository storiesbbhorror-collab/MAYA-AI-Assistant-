package com.maya.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.min
import kotlin.math.sin

class MayaAvatarView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var phase = 0f
    private val runnable = object : Runnable {
        override fun run() {
            phase += 0.045f
            invalidate()
            handler.postDelayed(this, 40L)
        }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null); handler.post(runnable) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val cx = w / 2f
        val cy = h / 2f + sin(phase.toDouble()).toFloat() * 4f
        val radius = min(w * 0.20f, h * 0.34f)

        // Ambient holographic halo.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, radius * 2.3f,
            intArrayOf(0x5533DDFF, 0x2233AAFF, 0x0033AAFF), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius * 2.3f, paint)
        paint.shader = null

        // Floating rings give a dimensional hologram effect.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.5f
        paint.color = 0xAA52E7FF.toInt()
        canvas.save()
        canvas.rotate(phase * 20f, cx, cy)
        canvas.drawOval(cx - radius * 1.65f, cy - radius * 0.48f, cx + radius * 1.65f, cy + radius * 0.48f, paint)
        canvas.restore()
        paint.color = 0x887E8BFF.toInt()
        canvas.save()
        canvas.rotate(-phase * 28f, cx, cy)
        canvas.drawOval(cx - radius * 1.4f, cy - radius * 0.6f, cx + radius * 1.4f, cy + radius * 0.6f, paint)
        canvas.restore()

        // Glossy orb face with a faux 3D radial highlight.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx - radius * 0.35f, cy - radius * 0.45f, radius * 1.65f,
            intArrayOf(0xFFB8FBFF.toInt(), 0xFF39BFE8.toInt(), 0xFF124A88.toInt(), 0xFF06142D.toInt()),
            floatArrayOf(0f, 0.35f, 0.72f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null

        // Glassy highlight.
        paint.color = 0x66FFFFFF
        canvas.drawOval(cx - radius * 0.60f, cy - radius * 0.68f, cx + radius * 0.10f, cy - radius * 0.30f, paint)

        // Animated eyes and smile.
        val eyeY = cy - radius * 0.08f
        val eyeGap = radius * 0.38f
        paint.color = 0xFF06172A.toInt()
        val eyeH = if ((phase % 7f) < 0.12f) 2f else radius * 0.16f
        canvas.drawOval(cx - eyeGap - radius * 0.10f, eyeY - eyeH / 2, cx - eyeGap + radius * 0.10f, eyeY + eyeH / 2, paint)
        canvas.drawOval(cx + eyeGap - radius * 0.10f, eyeY - eyeH / 2, cx + eyeGap + radius * 0.10f, eyeY + eyeH / 2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = maxOf(2f, radius * 0.045f)
        paint.color = 0xFF06172A.toInt()
        canvas.drawArc(cx - radius * 0.28f, cy + radius * 0.02f, cx + radius * 0.28f, cy + radius * 0.43f, 15f, 150f, false, paint)

        paint.style = Paint.Style.FILL
        paint.color = 0xFFE2FBFF.toInt()
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 13f * resources.displayMetrics.density
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        canvas.drawText("M A Y A", cx, h - 9f * resources.displayMetrics.density, paint)
        paint.shader = null
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(runnable)
        super.onDetachedFromWindow()
    }
}
