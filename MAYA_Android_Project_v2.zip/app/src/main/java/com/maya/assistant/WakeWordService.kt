package com.maya.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

class WakeWordService : Service() {
    companion object {
        const val ACTION_START = "com.maya.assistant.WAKE_START"
        const val ACTION_STOP = "com.maya.assistant.WAKE_STOP"
        private const val CHANNEL = "maya_wake_word"
        private const val NOTIFICATION_ID = 701
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var triggered = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopListening(); stopSelf(); return START_NOT_STICKY }
            else -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    // Foreground services can run without notification permission on some versions,
                    // but the notification is still shown in system task manager.
                }
                startForeground(NOTIFICATION_ID, buildNotification())
                beginListening()
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "MAYA Wake Word", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows when MAYA is listening for its wake phrase."
            })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 702, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("MAYA wake word चालू है")
                .setContentText("“Hey MAYA” / “हे माया” कहें। बंद करने के लिए MAYA ऐप खोलें।")
                .setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("MAYA wake word चालू है")
                .setContentText("“Hey MAYA” / “हे माया” कहें।")
                .setContentIntent(open).setOngoing(true).build()
        }
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        handler.removeCallbacksAndMessages(null)
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; restarting = false }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) { listening = false; scheduleRestart(1200) }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    val hit = matches.any { phrase ->
                        val p = phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z\\u0900-\\u097f ]"), " ").trim()
                        p.contains("hey maya") || p.contains("hey maia") || p.contains("हे माया") ||
                            p.contains("हेमाया") || p.contains("है माया")
                    }
                    if (hit && !triggered) {
                        triggered = true
                        handler.post {
                            try {
                                val launch = Intent(this@WakeWordService, MainActivity::class.java)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    .putExtra("maya_wake_triggered", true)
                                startActivity(launch)
                            } catch (e: Exception) { Log.w("MAYA", "Could not open app from wake phrase", e) }
                        }
                        scheduleRestart(5000)
                    } else scheduleRestart(400)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (matches.any { it.contains("hey maya", true) || it.contains("हे माया") || it.contains("हेमाया") }) {
                        // Wait for a final result to reduce accidental triggers.
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.w("MAYA", "Wake recognizer failed", e)
            scheduleRestart(3000)
        }
    }

    private fun scheduleRestart(delay: Long) {
        if (restarting) return
        restarting = true
        handler.postDelayed({
            restarting = false
            if (!triggered) beginListening()
            else {
                triggered = false
                beginListening()
            }
        }, delay)
    }

    private fun stopListening() {
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
