package com.maya.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.VideoProfile

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val call = MayaCallHolder.currentCall ?: return
        when (intent.action) {
            "com.maya.assistant.ANSWER_CALL" -> if (call.state == android.telecom.Call.STATE_RINGING) call.answer(VideoProfile.STATE_AUDIO_ONLY)
            "com.maya.assistant.REJECT_CALL" -> call.disconnect()
        }
    }
}
